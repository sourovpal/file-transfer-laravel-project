$(function(e) {

    "use strict";
      
      /*===========================================================================
      *
      *  CONFIGURATION DROPDOWN MENUS 
      *
      *============================================================================*/
      $(document).ready(function(){

          $('#set-aws-region').awselect();

          $('#support-category').awselect(); 

          $('#support-priority').awselect(); 

          $('#notification-type').awselect(); 

          $('#notification-action').awselect();

          $('#response-status').awselect();

          $('#server-encryption').awselect();

          $('#user-country').awselect();

          $('#user-status').awselect();

          $('#user-group').awselect();

          $('#smtp-encryption').awselect();

          $('#registration').awselect();

          $('#email-verification').awselect();

          $('#user-role').awselect();

          $('#login-oauth').awselect();

          $('#date-format').awselect();

          $('#time-zone').awselect();

          $('#support-ticket').awselect();

          $('#project').awselect();

          $('#faq-status').awselect();

          $('#user-notification').awselect();

          $('#user-support').awselect();

          $('#link-expiration').awselect();

          $('#password-protection').awselect();

          $('#link-expiration-user').awselect();

          $('#link-expiration-frontend').awselect();

          $('#password-protection-user').awselect();

          $('#password-protection-frontend').awselect();

          $('#type').awselect();

          $('#selected-share-method').awselect();

          $('#signed-link-duration').awselect();

          $('#2fa-status').awselect();

          $('#set-wasabi-region').awselect();

          $('#selected-storage').awselect();

          $('#plan-status').awselect();

          $('#currency').awselect();

          $('#featured').awselect();

          $('#duration').awselect();

          $('#free-plan').awselect();

          $('#password').awselect();

          $('#custom-expiration').awselect();

          $('#paypal-url').awselect();

          $('#braintree').awselect();

          $('#invoice-currency').awselect();

          $('#invoice-language').awselect();

          $('#invoice-country').awselect();

          $('#payment-option').awselect();

      }); 
  
  });
  
  
  