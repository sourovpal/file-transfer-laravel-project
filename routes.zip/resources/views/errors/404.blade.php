@extends('errors::layout')

@section('title', __('Page Not Found'))
@section('code', '404')
@section('message', __('Ooops! Looks like it is not here'))
